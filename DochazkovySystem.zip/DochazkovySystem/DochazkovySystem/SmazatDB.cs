﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DochazkovySystem
{
    public partial class SmazatDB : Form
    {
        public SmazatDB()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (DialogResult.Yes == MessageBox.Show("Opravdu chcete vymazat všechny data z datábáze?", "Odstranit data", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
            {
                int value = comboBox1.SelectedIndex;
                string table = "";
                database x = database.getDatabase();
                string sConnectionString = x.getString();
                SqlConnection con = new SqlConnection(sConnectionString);

                switch (value)
                {
                    case 0:
                        table = "Dochazka";
                        break;
                    case 1:
                        table = "StatusDne";
                        break;
                    case 2:
                        table = "Zamestnanec";
                        break;
                    default:
                        return;
                }

                try
                {
                    if (con.State != ConnectionState.Open) con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "Delete  FROM " + table + "";
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                catch (Exception)
                {
                    MessageBox.Show("Chyba mazani db!!");
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
