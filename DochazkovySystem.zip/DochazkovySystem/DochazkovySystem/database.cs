﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DochazkovySystem
{
	public class database
	{
		private static database instant = null;
		private string sConnectionString =
                String.Format("{0};{1}\"{2}\"{3}",
                @"Data Source=(LocalDB)\v11.0",
                 "AttachDbFilename=",
                  System.IO.Path.GetFullPath(@"..\..\dochazka.mdf"),
                  ";Integrated Security=True;Connect Timeout=30");


		private string sConnectionString1 =
				String.Format("{0};{1}\"{2}\"{3}",
				@"Data Source=(LocalDB)\MSSQLLocalDB",
                 "AttachDbFilename=",
                  System.IO.Path.GetFullPath(@"..\..\dochazka.mdf"),
                  ";Integrated Security=True;Connect Timeout=30");
		bool old;

		private database ()
		{	
			old = true; 
		}
		public static database getDatabase(){
			if (instant!=null)
				return instant;
			else {
			 instant = new database();
			 return instant;
			 }
				

		}
		public string getString() { 
		
		if (this.old==true)
			return sConnectionString;
		else 
			return sConnectionString1;
		
		}

		public void setNew()
		{
			this.old = false;
		}
	}
}
