﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DochazkovySystem
{
	public partial class Form1 : Form
	{
		private SqlDataAdapter dataAdapter = new SqlDataAdapter();
		private SqlDataAdapter dataAdapter1 = new SqlDataAdapter();
		private SqlDataAdapter dataAdapter2 = new SqlDataAdapter();
		public Form1()
		{
			InitializeComponent();
			GetData();
		}

		private void label1_Click(object sender, EventArgs e)
		{

		}

		private void button1_Click(object sender, EventArgs e)
		{

		}

		private void button2_Click(object sender, EventArgs e)
		{
			

		}

		private void vložStatusToolStripMenuItem_Click(object sender, EventArgs e)
		{
			
		}

		private void tabPage1_Click(object sender, EventArgs e)
		{

		}

		private void GetData()
		{
			try
			{
			    string sConnectionString =
				String.Format("{0};{1}\"{2}\"{3}",
				@"Data Source=(LocalDB)\v11.0",
				 "AttachDbFilename=",
				  System.IO.Path.GetFullPath(@"..\..\dochazka.mdf"),
				  ";Integrated Security=True;Connect Timeout=30");

				
				dataAdapter = new SqlDataAdapter("Select * FROM StatusDne where 1=1 Order by Nazev ASC", sConnectionString);
				dataAdapter1 = new SqlDataAdapter("Select * FROM Zamestnanec where 1=1 Order by Prijmeni ASC", sConnectionString);
				
				SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
				SqlCommandBuilder commandBuilder1 = new SqlCommandBuilder(dataAdapter1);

				DataTable table = new DataTable();
				DataTable table1 = new DataTable();
				table.Locale = System.Globalization.CultureInfo.InvariantCulture;
				dataAdapter.Fill(table);
				table1.Locale = System.Globalization.CultureInfo.InvariantCulture;
				dataAdapter1.Fill(table1);

				bindingSource1.DataSource = table;
				bindingSource2.DataSource = table1;

				dataGridView2.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
				dataGridView1.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

				dataGridView2.DataSource = bindingSource1;
				dataGridView1.DataSource = bindingSource2;
				
			}
			catch (Exception e)
			{
				MessageBox.Show("Chby db!!");
			}
		}

		private void button2_Click_1(object sender, EventArgs e)
		{
			Form status = new VlozStatus();
			status.ShowDialog();
			GetData();
		}


		private void label1_Click_1(object sender, EventArgs e)
		{

		}

		private void button3_Click(object sender, EventArgs e)
		{
			Form zam = new VlozZamestnance();
			zam.ShowDialog();
			GetData();
		}
	}
}
