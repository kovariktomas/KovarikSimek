﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Xml;

namespace DochazkovySystem
{
	
	public partial class Form1 : Form
	{
		private SqlDataAdapter dataAdapter = new SqlDataAdapter();
		private SqlDataAdapter dataAdapter1 = new SqlDataAdapter();
		private SqlDataAdapter dataAdapter2 = new SqlDataAdapter();
		int load = 1;
		
		public Form1()
		{	this.load=1;
			database x = database.getDatabase();
			
			if (DialogResult.Yes ==	MessageBox.Show("Verze pro visual 2015", "Databáze", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
				x.setNew();

			InitializeComponent();
			GetData();
			
		}

		private void label1_Click(object sender, EventArgs e)
		{

		}

		private void button1_Click(object sender, EventArgs e)
		{

		}

		private void button2_Click(object sender, EventArgs e)
		{
			

		}

		private void vložStatusToolStripMenuItem_Click(object sender, EventArgs e)
		{
			
		}

		private void tabPage1_Click(object sender, EventArgs e)
		{

		}

		private void GetData()
		{
			try
			{	database x = database.getDatabase();
			    string sConnectionString = x.getString();
				/*
				String.Format("{0};{1}\"{2}\"{3}",
				@"Data Source=(LocalDB)\v11.0",
				 "AttachDbFilename=",
				  System.IO.Path.GetFullPath(@"..\..\dochazka.mdf"),
				  ";Integrated Security=True;Connect Timeout=30");
				  */
				
				dataAdapter = new SqlDataAdapter("Select * FROM StatusDne where 1=1 Order by Nazev ASC", sConnectionString);
				dataAdapter1 = new SqlDataAdapter("Select * FROM Zamestnanec where 1=1 Order by Prijmeni ASC", sConnectionString);
				
				SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
				SqlCommandBuilder commandBuilder1 = new SqlCommandBuilder(dataAdapter1);

				DataTable table = new DataTable();
				DataTable table1 = new DataTable();
				table.Locale = System.Globalization.CultureInfo.InvariantCulture;
				dataAdapter.Fill(table);
				table1.Locale = System.Globalization.CultureInfo.InvariantCulture;
				dataAdapter1.Fill(table1);

				bindingSource1.DataSource = table;
				bindingSource2.DataSource = table1;

				dataGridView2.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
				dataGridView1.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

				dataGridView2.DataSource = bindingSource1;
				dataGridView1.DataSource = bindingSource2;
				
			}
			catch (Exception e)
			{
				MessageBox.Show("Chby db!!");
			}
		}

		private void GetDochazka(int id_zam)
		{
			try
			{
				database x = database.getDatabase();
				string sConnectionString = x.getString();
				/*
				String.Format("{0};{1}\"{2}\"{3}",
				@"Data Source=(LocalDB)\v11.0",
				 "AttachDbFilename=",
				  System.IO.Path.GetFullPath(@"..\..\dochazka.mdf"),
				  ";Integrated Security=True;Connect Timeout=30");
				  */


				dataAdapter2 = new SqlDataAdapter("Select * FROM Dochazka where Zamestnanec = "+id_zam+" Order by Datum ASC", sConnectionString);
				

				SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter2);
				

				DataTable table = new DataTable();
				
				table.Locale = System.Globalization.CultureInfo.InvariantCulture;
				dataAdapter2.Fill(table);
			

				bindingSource3.DataSource = table;
				

				dataGridView3.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
				dataGridView3.DataSource = bindingSource3;
				dataGridView4.DataSource = bindingSource3;
				dataGridView4.Columns[0].Visible = false;
				dataGridView4.Columns[6].Visible = false;
				

			}
			catch (Exception e)
			{
				MessageBox.Show("Chyba db!!");
			}
		}

		private void button2_Click_1(object sender, EventArgs e)
		{
			Form status = new VlozStatus();
			status.ShowDialog();
			GetData();
		}


		private void label1_Click_1(object sender, EventArgs e)
		{

		}

		private void button3_Click(object sender, EventArgs e)
		{
			Form zam = new VlozZamestnance();
			zam.ShowDialog();
			GetData();
		}

	private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{

		}

		private void dataGridView1_SelectionChanged(object sender, EventArgs e)
		{
			try {
			if (this.load==0)
				GetDochazka(System.Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value));
			}
			catch (Exception ex)
			{


			}
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			this.load = 0;
			dataGridView1_SelectionChanged(sender, e);
		}

		private void label3_Click(object sender, EventArgs e)
		{

		}

		private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
		{
			try {
				if (dateTimePicker2.Value < dateTimePicker1.Value)
				dateTimePicker2.Value = dateTimePicker1.Value.AddDays(1) ;

				dateTimePicker4.Value = dateTimePicker1.Value;
				bindingSource3.Filter = String.Format("Datum >= '{0:yyyy-MM-dd}' AND Datum < '{1:yyyy-MM-dd}'", dateTimePicker1.Value, dateTimePicker2.Value);
				
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		
		}

		private void button4_Click(object sender, EventArgs e)
		{
			Form dochazka = new VlozDochazku(bindingSource2, bindingSource1);
			dochazka.ShowDialog();
			dataGridView1_SelectionChanged(sender, e);
		
		}

		private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
		{
			try
			{
				if (dateTimePicker2.Value < dateTimePicker1.Value)
					dateTimePicker1.Value = dateTimePicker2.Value.AddDays(-1);

				dateTimePicker3.Value = dateTimePicker2.Value;
				bindingSource3.Filter = String.Format("Datum >= '{0:yyyy-MM-dd}' AND Datum < '{1:yyyy-MM-dd}'", dateTimePicker1.Value, dateTimePicker2.Value);

			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void button1_Click_1(object sender, EventArgs e)
		{
			bindingSource2.Filter = String.Format("Rc like  '*{0}*'", textBox1.Text);
		}

		private void button5_Click(object sender, EventArgs e)
		{
			bindingSource2.Filter = String.Format("Rc like  '*'");
			 textBox1.Text = "";
		}

		private void label10_Click(object sender, EventArgs e)
		{

		}

		private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
		{

		}

		private void button6_Click(object sender, EventArgs e)
		{
			textBox6.Text = dateTimePicker1.Value.ToString("dd. MM. yyyy");
			textBox7.Text = dateTimePicker2.Value.ToString("dd. MM. yyyy");
			textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString()+" "+dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
			textBox3.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
			textBox4.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
			textBox5.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();

			textBox8.Text = (System.Convert.ToInt32(dataGridView3.RowCount.ToString())-1).ToString();
			float odpracovano = 0;
			int pocet = 0;
			float dovolena = 0;
			float nemoc = 0;
			float ostatni = 0;
			float predcas = 0;
			
			foreach (DataGridViewRow row in dataGridView3.Rows)
			{ 
				if (System.Convert.ToInt32(row.Cells[5].Value) == 1)
				{
					odpracovano += (float) (System.Convert.ToDecimal(row.Cells[4].Value.ToString()));
					pocet++;
				}
				else if (System.Convert.ToInt32(row.Cells[5].Value) == 2)
					dovolena++;
				else if (System.Convert.ToInt32(row.Cells[5].Value) == 3)
					nemoc++;
				else if (System.Convert.ToInt32(row.Cells[5].Value) == 4) {
					odpracovano += (float)(0.5) * (float)(Convert.ToInt32(row.Cells[4].Value));
					pocet++;
					dovolena += (float)(0.5);
				}
				else
					ostatni++;

			}

			textBox9.Text = odpracovano.ToString();

			textBox10.Text = dovolena.ToString();

			textBox11.Text = nemoc.ToString();

			textBox12.Text = (((float)(System.Convert.ToDecimal(dataGridView1.SelectedRows[0].Cells[6].Value.ToString())) /5 * pocet) - odpracovano) < 0 ? ((((float)(System.Convert.ToDecimal(dataGridView1.SelectedRows[0].Cells[6].Value.ToString()))/5 * pocet) - odpracovano)*-1).ToString() : "0";
		}

		private void textBox3_TextChanged(object sender, EventArgs e)
		{

		}

		private void importToolStripMenuItem_Click(object sender, EventArgs e)
		{
			OpenFileDialog o = new OpenFileDialog();
			if (DialogResult.OK ==o.ShowDialog()){
			string filename = o.FileName;
			XmlDocument doc = new XmlDocument();
			doc.Load(filename);
			DateTime datum = new DateTime(), prichod = new DateTime(), odchod = new DateTime();
			int zamestnanec=-1;
			int statusdne=-1;
			foreach (XmlNode node in doc.DocumentElement.ChildNodes)
			{
				foreach (XmlNode nodes in node.ChildNodes)
				{
					
					switch (nodes.Name.ToString()) {
						case "Datum": datum = Convert.ToDateTime(nodes.InnerText);
						break;
						case "Prichod": prichod = Convert.ToDateTime(nodes.InnerText);
										prichod = Convert.ToDateTime(datum.Day.ToString()+". "+datum.Month.ToString()+". "+datum.Year.ToString()+" "+prichod.Hour.ToString()+":"+prichod.Minute.ToString()+":"+prichod.Second.ToString());
						break;
						case "Odchod": odchod = Convert.ToDateTime(nodes.InnerText);
						odchod = Convert.ToDateTime(datum.Day.ToString() + ". " + datum.Month.ToString() + ". " + datum.Year.ToString() + " " + odchod.Hour.ToString() + ":" + odchod.Minute.ToString() + ":" + odchod.Second.ToString());
						break;
						case "StatusDne": statusdne = System.Convert.ToInt32(nodes.InnerText);
						break;
						case "Zamestnanec": zamestnanec = System.Convert.ToInt32(nodes.InnerText);
						break;
					}
					
				}
				new Dochazka(datum, prichod, odchod, zamestnanec, statusdne);
			}
			MessageBox.Show("Import dokončen");
			}
		}

		private void exportToolStripMenuItem_Click(object sender, EventArgs e)
		{
			tabControl1.SelectedIndex = 4;
		}

		private void button7_Click(object sender, EventArgs e)
		{
			saveFileDialog1.FileName = "Dochazka od " + dateTimePicker4.Value.Day.ToString() + ". " + dateTimePicker4.Value.Month.ToString() + ". " + dateTimePicker4.Value.Year.ToString() + " do od " + dateTimePicker3.Value.Day.ToString() + ". " + dateTimePicker3.Value.Month.ToString() + ". " + dateTimePicker3.Value.Year.ToString();
			
			if (DialogResult.OK ==saveFileDialog1.ShowDialog()) { 
			// Create the XmlDocument.
			XmlDocument doc = new XmlDocument();
			doc.LoadXml("<zamestnanci></zamestnanci>");
			
			for (int i = 0; i<dataGridView1.RowCount-2;i++)
			{
				this.dataGridView1.CurrentCell = this.dataGridView1[0, i];
				this.button6_Click(sender, e);
				XmlElement od = doc.CreateElement("od");
				od.InnerText = textBox6.Text;
				XmlElement odo = doc.CreateElement("do");
				odo.InnerText = textBox7.Text;
				XmlElement jm = doc.CreateElement("JmenoPrijmeni");
				jm.InnerText = textBox2.Text;
				XmlElement rc = doc.CreateElement("RodneCislo");
				rc.InnerText = textBox3.Text;
				XmlElement pozice = doc.CreateElement("Pozice");
				pozice.InnerText = textBox4.Text;
				XmlElement uvazek = doc.CreateElement("Uvazek");
				uvazek.InnerText = textBox5.Text;
				XmlElement odprac = doc.CreateElement("Odpracovano");
				odprac.InnerText = textBox9.Text;
				XmlElement dovol = doc.CreateElement("Dovolena");
				dovol.InnerText = textBox10.Text;
				XmlElement nemoc = doc.CreateElement("Nemoc");
				nemoc.InnerText = textBox11.Text;
				XmlElement pred = doc.CreateElement("Predcas");
				pred.InnerText = textBox12.Text;
				XmlElement zamestnanec = doc.CreateElement("Zamestnanec");
				zamestnanec.AppendChild(od);
				zamestnanec.AppendChild(odo);
				zamestnanec.AppendChild(jm);
				zamestnanec.AppendChild(rc);
				zamestnanec.AppendChild(pozice);
				zamestnanec.AppendChild(uvazek);
				zamestnanec.AppendChild(odprac);
				zamestnanec.AppendChild(dovol);
				zamestnanec.AppendChild(nemoc);
				zamestnanec.AppendChild(pred);
				zamestnanec.AppendChild(od);
				zamestnanec.AppendChild(od);
				zamestnanec.AppendChild(odo);
				zamestnanec.AppendChild(odo);
				doc.DocumentElement.AppendChild(zamestnanec);
			}
		
			doc.PreserveWhitespace = true;
			doc.Save(saveFileDialog1.FileName);
			MessageBox.Show("Export dokončen");
			}
		}

		private void dateTimePicker3_ValueChanged(object sender, EventArgs e)
		{
			dateTimePicker2.Value = dateTimePicker3.Value;
		}

		private void dateTimePicker4_ValueChanged(object sender, EventArgs e)
		{
			dateTimePicker1.Value = dateTimePicker4.Value;

			

		}

	




	}
}
