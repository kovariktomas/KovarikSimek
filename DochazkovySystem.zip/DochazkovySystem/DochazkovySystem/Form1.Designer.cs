﻿namespace DochazkovySystem
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.souborToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.importToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.exportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.konecToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.nastaveníToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.databázeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.vymazatDatabáziToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.zálohovatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.obnovaZeZálohyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.nápovědaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.oAplikaciToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.button1 = new System.Windows.Forms.Button();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.menuStrip1.SuspendLayout();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			this.SuspendLayout();
			// 
			// menuStrip1
			// 
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.souborToolStripMenuItem,
            this.nastaveníToolStripMenuItem,
            this.nápovědaToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(597, 24);
			this.menuStrip1.TabIndex = 0;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// souborToolStripMenuItem
			// 
			this.souborToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importToolStripMenuItem,
            this.exportToolStripMenuItem,
            this.konecToolStripMenuItem});
			this.souborToolStripMenuItem.Name = "souborToolStripMenuItem";
			this.souborToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
			this.souborToolStripMenuItem.Text = "Soubor";
			// 
			// importToolStripMenuItem
			// 
			this.importToolStripMenuItem.Name = "importToolStripMenuItem";
			this.importToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
			this.importToolStripMenuItem.Text = "Import";
			// 
			// exportToolStripMenuItem
			// 
			this.exportToolStripMenuItem.Name = "exportToolStripMenuItem";
			this.exportToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
			this.exportToolStripMenuItem.Text = "Export";
			// 
			// konecToolStripMenuItem
			// 
			this.konecToolStripMenuItem.Name = "konecToolStripMenuItem";
			this.konecToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
			this.konecToolStripMenuItem.Text = "Konec";
			// 
			// nastaveníToolStripMenuItem
			// 
			this.nastaveníToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.databázeToolStripMenuItem});
			this.nastaveníToolStripMenuItem.Name = "nastaveníToolStripMenuItem";
			this.nastaveníToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
			this.nastaveníToolStripMenuItem.Text = "Nastavení";
			// 
			// databázeToolStripMenuItem
			// 
			this.databázeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vymazatDatabáziToolStripMenuItem,
            this.zálohovatToolStripMenuItem,
            this.obnovaZeZálohyToolStripMenuItem});
			this.databázeToolStripMenuItem.Name = "databázeToolStripMenuItem";
			this.databázeToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
			this.databázeToolStripMenuItem.Text = "Databáze";
			// 
			// vymazatDatabáziToolStripMenuItem
			// 
			this.vymazatDatabáziToolStripMenuItem.Name = "vymazatDatabáziToolStripMenuItem";
			this.vymazatDatabáziToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
			this.vymazatDatabáziToolStripMenuItem.Text = "Vymazat databázi";
			// 
			// zálohovatToolStripMenuItem
			// 
			this.zálohovatToolStripMenuItem.Name = "zálohovatToolStripMenuItem";
			this.zálohovatToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
			this.zálohovatToolStripMenuItem.Text = "Zálohovat";
			// 
			// obnovaZeZálohyToolStripMenuItem
			// 
			this.obnovaZeZálohyToolStripMenuItem.Name = "obnovaZeZálohyToolStripMenuItem";
			this.obnovaZeZálohyToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
			this.obnovaZeZálohyToolStripMenuItem.Text = "Obnova ze zálohy";
			// 
			// nápovědaToolStripMenuItem
			// 
			this.nápovědaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oAplikaciToolStripMenuItem});
			this.nápovědaToolStripMenuItem.Name = "nápovědaToolStripMenuItem";
			this.nápovědaToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
			this.nápovědaToolStripMenuItem.Text = "Nápověda";
			// 
			// oAplikaciToolStripMenuItem
			// 
			this.oAplikaciToolStripMenuItem.Name = "oAplikaciToolStripMenuItem";
			this.oAplikaciToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
			this.oAplikaciToolStripMenuItem.Text = "O aplikaci";
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Controls.Add(this.tabPage3);
			this.tabControl1.Location = new System.Drawing.Point(0, 27);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(597, 305);
			this.tabControl1.TabIndex = 1;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.button1);
			this.tabPage1.Controls.Add(this.textBox1);
			this.tabPage1.Controls.Add(this.label1);
			this.tabPage1.Controls.Add(this.dataGridView1);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(589, 279);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Data";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// tabPage2
			// 
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(589, 279);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Grafy";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// tabPage3
			// 
			this.tabPage3.Location = new System.Drawing.Point(4, 22);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Size = new System.Drawing.Size(589, 279);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "Export";
			this.tabPage3.UseVisualStyleBackColor = true;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(134, 28);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 7;
			this.button1.Text = "Vyhledat";
			this.button1.UseVisualStyleBackColor = true;
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(18, 31);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(101, 20);
			this.textBox1.TabIndex = 6;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(15, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(104, 13);
			this.label1.TabIndex = 5;
			this.label1.Text = "Jméno zaměstnance";
			// 
			// dataGridView1
			// 
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Location = new System.Drawing.Point(18, 66);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.Size = new System.Drawing.Size(191, 150);
			this.dataGridView1.TabIndex = 4;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(597, 332);
			this.Controls.Add(this.tabControl1);
			this.Controls.Add(this.menuStrip1);
			this.MainMenuStrip = this.menuStrip1;
			this.Name = "Form1";
			this.Text = "Docházkový systém";
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem souborToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem importToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem exportToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem konecToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem nastaveníToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem databázeToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem vymazatDatabáziToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem zálohovatToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem obnovaZeZálohyToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem nápovědaToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem oAplikaciToolStripMenuItem;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.DataGridView dataGridView1;
	}
}

