﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DochazkovySystem
{
    public partial class SpravaDB : Form
    {
        public SpravaDB()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dlg = new FolderBrowserDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = dlg.SelectedPath;
                button1.Enabled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            database x = database.getDatabase();
            string sConnectionString = x.getString();
            SqlConnection con = new SqlConnection(sConnectionString);

            if (textBox1.Text != string.Empty)
            {
                try
                {
                    if (con.State != ConnectionState.Open) con.Open();
                    string mydatabase = con.Database.ToString();
                    string cmd = "BACKUP DATABASE [" + mydatabase + "]  TO DISK='" + textBox1.Text + "\\" + "Database" + "-" + DateTime.Now.ToString("MM-dd-HH-mm-ss ") + ".bak'";

                    using (SqlCommand command = new SqlCommand(cmd, con))
                    {
                        command.ExecuteNonQuery();
                        MessageBox.Show("Záloha databáze proběhla úspěšně");
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Chyba mazani db!!");
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "SQL SERVER database backup files|*.bak";
            dlg.Title = "Obnova databaze";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                textBox2.Text = dlg.FileName;
                button4.Enabled = true;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            database x = database.getDatabase();
            string sConnectionString = x.getString();
            SqlConnection con = new SqlConnection(sConnectionString);

            try
            {
                if (con.State != ConnectionState.Open) con.Open();
                string mydatabase = con.Database.ToString();

                string sqlStmt2 = string.Format("ALTER DATABASE [" + mydatabase + "] SET SINGLE_USER WITH ROLLBACK IMMEDIATE");
                SqlCommand bu2 = new SqlCommand(sqlStmt2, con);
                bu2.ExecuteNonQuery();

                string sqlStmt3 = "USE MASTER RESTORE DATABASE [" + mydatabase + "] FROM DISK='" + textBox2.Text + "'WITH REPLACE;";
                SqlCommand bu3 = new SqlCommand(sqlStmt3, con);
                bu3.ExecuteNonQuery();

                string sqlStmt4 = string.Format("ALTER DATABASE [" + mydatabase + "] SET MULTI_USER");
                SqlCommand bu4 = new SqlCommand(sqlStmt4, con);
                bu4.ExecuteNonQuery();

                MessageBox.Show("Obnova databáze proběhla úspěšně");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.Close();
            }
        }

 
    }
}
