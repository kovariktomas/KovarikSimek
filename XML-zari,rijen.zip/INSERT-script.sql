
-- version 1.3
-- Table: `Zamestnanec`
--
 
INSERT IGNORE INTO `Zamestnanec` 
(`id`,`Jmeno`,`Prijmeni`,`RC`          ,`datumNas`,`pracovniPozice`,`TydenniUvazekH`) VALUES
( 0,'Vlasta','Kasparkova','396031/9253','09-10-2013','Uklid',40 ),
( 1,'Mikulas','Jurka','771009/2830','77-10-2014','Developer',40 ),
( 2,'Bianka','Jiraskova','795524/0337','09-05-2013','Developer',40 ),
( 3,'Otylie','Sykorova','685428/5977','08-04-2013','Developer',40 ),
( 4,'Alannah','Svabova','865827/3063','06-08-2015','Developer Junior',40 ),
( 5,'Bozena','Olivova','015426/4385','01-04-2015','Tester Senior',40 ),
( 6,'Iris','Maleckova','495406/7206','09-04-2015','Tester Senior',40 ),
( 7,'Aimee','Starova','616228/5250','01-12-2015','Developer Junior',40 ),
( 8,'Rene','Krupka','590417/9908','09-04-2015','Developer Senior',40 ),
( 9,'Matylda','Ptackova','496220/4159','09-12-2013','Developer Senior',40 ),
( 10,'Jindrich','Doubrava','131127/4613','03-11-2015','CFO - Chief Financial Offecer',40 ),
( 11,'Mariana','Liskova','005510/8977','01-05-2015','Human Resouces',40 ),
( 12,'Jenovefa','Matuskova','446210/8673','04-12-2014','Human Resouces',40 ),
( 13,'Tomas','Prosek','451014/2758','05-10-2015','Financial Accountant',40 ), 
( 14,'Jan','Vit','880411/3395','08-04-2015','Financial Accountant',40 ),
( 15,'Konrad','Peroutka','430712/1247','03-07-2015','Customer service',40 ),
( 16,'Bohuslav','Cernohorsky','380114/7658','08-01-2013','Product Manager',40 ),
( 17,'Amata','Petrasova','155421/4893','12-04-2015','Assistant CEO',40 ),
( 18,'Zbynek','Beranek','450914/9788','13-09-2013','Company Lawyer',40 ),
( 19,'Frantisek','Voracek','050914/9788','05-09-2013','CEO - Chief Exclusive Officer',40 ),
( 20,'Aloisie','Bilkova','176011/4521','17-10-2014','CTO - Chief Technical Officer',40 );

 